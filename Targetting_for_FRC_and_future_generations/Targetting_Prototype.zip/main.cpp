#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

#define max(a, b) (a > b ? a : b )
#define min(a, b) (a < b ? a : b )

//NOTE: These are the camera matrix and distortion coefficients for a Moto G phone.
//Will add a calibrator if I have the time.
double fCameraMatrix[3][3] = { { 1260.029, 0, 650.7481 },
										{ 0, 1259.2968, 341.3892 },
										{ 0, 0, 1 } };
//double fCameraMatrix[3][3] = { { 1265.8395, 0, 669.8386 },
//										{ 0, 1264.6891, 464.8123 },
//										{ 0, 0, 1 } };
cv::Mat mCameraMatrix = Mat( 3, 3, CV_64F, &fCameraMatrix );
double fDistortionCoeffs[] = { 0.1282, -0.646, 0, 0, 0.319 };
//double fDistortionCoeffs[] = { 0.0867, -0.3144, 0, 0, 0.1708 };
cv::Mat mDistortionCoeffs = Mat( 1, 5, CV_64F, &fDistortionCoeffs );

//TODO: Make these customizable in an XML or text file.
//All the measurements below are in millimeters, save for the pixel size which is in micrometers.
//Retrieved from http://www.ovt.com/products/sensor.php?id=43, which is the Pixy Camera's image sensor.
//The values underneath are actually for my phone (Moto G), changed for testing. Will change them back when done.
#define FOCAL_LENGTH 3.5f				//PIXY: 2.800f
#define PIXEL_SIZE 1.4f					//PIXY: 3.0f
#define IMAGE_SENSOR_W 3.6288f		//PIXY: 3.888f * 3.0f = 11.664f
#define IMAGE_SENSOR_H 2.0384f				//PIXY: 2.430 * 3.0f = 7.290f

#define HUE_MIN 60	//COMP: ~160
#define HUE_MAX 100	//COMP: ~190
#define SAT_MIN 25
#define VAL_MIN 30

//Measured in centimeters.
//TODO: These are for an experimental target I used.
#define TARGET_WIDTH 4.05f
#define TARGET_HEIGHT 6.7f
#define TARGET_GROUND 26.0f		//Height from the ground

#define PI 3.1415926535897932384626433832795f

int main( int argc, char** argv )
{
    if(argc != 2)
    {
		cout <<" Usage: display_image ImageToLoadAndDisplay" << endl;
		return -1;
    }

	Mat import = imread(argv[1], IMREAD_COLOR);
	//Mat image = import.clone();
	Mat image( import.rows, import.cols, CV_8UC1 );
	cv::undistort( import, image, mCameraMatrix, mDistortionCoeffs );
	cvtColor( image, image, CV_BGR2HSV );

	cout << image.rows << "\n";
	cout << image.cols << "\n";
	
    if( !image.data ) // Check for invalid input
    {
        cout << "Could not open or find the image" << std::endl;
        return -1;
    }

	//Filter out anything that is not greenish-blue (target's color)
	//Then make whatever's left plain white and convert back to BGR.
	medianBlur( image, image, 5 );
	for (int i=0; i< image.rows; i++)
    {
        for (int j=0; j< image.cols; j++)
        {
            Vec3b editValue=image.at<Vec3b>(i,j);

			if ( image.at<Vec3b>(i,j)[0] > HUE_MIN / 2 && image.at<Vec3b>(i,j)[0] < HUE_MAX / 2
				&& image.at<Vec3b>(i,j)[1] > SAT_MIN * 2.55
				&& image.at<Vec3b>(i,j)[2] > VAL_MIN * 2.55 )
			{
				image.at<Vec3b>(i,j)[1] = 0;
				image.at<Vec3b>(i,j)[2] = 128;
			}
			else
			{
				image.at<Vec3b>(i,j) = 0;
			}
        }
    }
	cvtColor( image, image, CV_HSV2BGR );

	Mat canny_output;
	Canny( image, canny_output, 100, 200, 3 );
	vector<vector<Point> > contours_a;
	findContours( canny_output, contours_a, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE );
	Mat img2 = Mat::zeros( image.rows, image.cols, CV_8U );
	vector<vector<Point>> contours;
	for ( unsigned int i = 0; i < contours_a.capacity(); i++ )	//Purge contours that are too small.
	{
		if ( cv::contourArea( contours_a[i] ) < 50 ) continue;
		contours.push_back( contours_a[i] );
	}
	//assert( contours.capacity() == 2 );
	for ( unsigned int i = 0; i < contours.capacity(); i++ )
	{
		drawContours( img2, contours, i, 255, 1, 8 );
		cv::rectangle( img2, cv::boundingRect( contours[i] ), 128, 1 );
		cout << cv::boundingRect( contours[i] ) << endl;
	}
	/*Rect a = cv::boundingRect( contours[0] );
	Rect b = cv::boundingRect( contours[1] );
	Rect c = Rect( cv::Point(min(a.x, b.x), min(a.y,b.y)), cv::Point(max(a.x+a.width,b.x+b.width), max(a.y+a.height,b.y+b.height)) );*/
	//assert( contours.capacity() == 1 );
	Rect c = cv::boundingRect( contours[0] );
	cout << c << endl;
	cv::rectangle( image, c, 255, 1 );
	//If the picture's width:height ratio is over 10% lower than that of the real target,
	//we should assume that the target in the image is being cut off.
	assert( (c.width / (float)c.height) >=
				(TARGET_WIDTH / TARGET_HEIGHT) - ((TARGET_WIDTH / TARGET_HEIGHT) * 0.1f) );

	//Here's another idea for finding the distance:
	/*
		Distance(mm) = f(mm) * real_height(mm) * image_height(pixels)
							-------------------------------------------------------
							object_height(pixels) * sensor_height(mm)
							
		To calculate theoretical height: H2 = (W2 * H1) / W1
		
		Also works with width instead of height.
		Using width, should work regardless of the vertical angle the target's viewed at.
		Only the object height/width would change, in the context of this program.
		Source: http://photo.stackexchange.com/questions/12434/how-do-i-calculate-the-distance-of-an-object-in-a-photo
	*/

	const float fApproxDistance = ( (FOCAL_LENGTH * (TARGET_WIDTH * 10.0f) * import.cols)
										/ (c.width * IMAGE_SENSOR_W) ) / 10.0f;

	//Horizontal FOV = 2 * atan(d / 2f) [where d = sensor width and f = focal length)
	const float fApproxHFOV = (float)(2 * std::atan( IMAGE_SENSOR_W / (2 * FOCAL_LENGTH) ) * (180 / PI));

	int iXDist = std::abs( (640 - (c.x + c.width / 2)) );
	const float fApproxHAngle = (iXDist / ((float)image.cols / 2)) * fApproxHFOV;

	const float fApproxXDist = std::sqrt( fApproxDistance * fApproxDistance - TARGET_GROUND * TARGET_GROUND );	//a^2 + b^2 = c^2
	std::cout << TARGET_GROUND << endl;
	std::cout << fApproxDistance << endl;
	std::cout << TARGET_GROUND / fApproxDistance << endl;
	const float fApproxVAngle = std::asin( TARGET_GROUND / fApproxDistance ) * (180 / PI);	//sin = opp / hyp

	std::cout << "Approximate distance: " << fApproxDistance << "cm" << std::endl;
	std::cout << "Approximate horizontal angle: " << fApproxHAngle << " degrees [" << (c.x > image.cols / 2 ? "right" : "left") << "]" << std::endl;
	std::cout << "Approximate vertical angle: " << fApproxVAngle << " degrees" << std::endl;

	cv::imwrite( "_temp.jpg", image );
    namedWindow( "Display window", WINDOW_AUTOSIZE );
    imshow( "Display window", image );

    waitKey(0);
    return 0;
}